# web3.py balancer
A class that handles web3 connections and rotates between them to balance out the requests.
## Requirements 
- web3
- tor service running (if you wish to use tor)
- loguru (only for logging)

## Usage
